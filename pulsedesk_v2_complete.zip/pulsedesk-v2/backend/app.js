require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { errorHandler } = require('./middleware/error.middleware');

const app = express();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'PulseDesk API', timestamp: new Date() }));

app.use('/api/auth',         require('./routes/auth.routes'));
app.use('/api/users',        require('./routes/user.routes'));
app.use('/api/clients',      require('./routes/client.routes'));
app.use('/api/departments',  require('./routes/department.routes'));
app.use('/api/jobs',         require('./routes/job.routes'));
app.use('/api/daily-logs',   require('./routes/dailyLog.routes'));
app.use('/api/reports',      require('./routes/report.routes'));
app.use('/api/hr',           require('./routes/hr.routes'));
app.use('/api/notifications',require('./routes/notification.routes'));
app.use('/api/workspace',    require('./routes/workspace.routes'));
app.use('/api/upload',       require('./routes/upload.routes'));

app.use(errorHandler);

module.exports = app;
