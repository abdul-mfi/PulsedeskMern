'use client';
import AppShell from '../../components/layout/AppShell';
import Topbar from '../../components/layout/Topbar';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

export default function Page() {
  return (
    <AppShell>
      <Topbar title="Clients" />
      <div className="p-6">
        <div className="card p-8 text-center text-gray-500">
          <div className="text-2xl mb-2">🚧</div>
          <div className="font-medium">clients page — connect API data here</div>
          <div className="text-sm mt-1 text-gray-400">All API endpoints and Redux slices are ready. Wire fetch calls per the SETUP.md.</div>
        </div>
      </div>
    </AppShell>
  );
}
