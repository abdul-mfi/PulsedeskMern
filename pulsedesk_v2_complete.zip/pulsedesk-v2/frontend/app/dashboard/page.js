'use client';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AppShell from '../../components/layout/AppShell';
import Topbar from '../../components/layout/Topbar';
import StatCard from '../../components/ui/StatCard';
import StatusPill from '../../components/ui/StatusPill';
import RingProgress from '../../components/ui/RingProgress';
import Avatar from '../../components/ui/Avatar';
import Button from '../../components/ui/Button';
import { fetchJobs, fetchStats } from '../../store/slices/jobsSlice';
import { fetchNotifs, fetchUnread } from '../../store/slices/notificationsSlice';
import { openPanel } from '../../store/slices/uiSlice';
import { getDaysLeft, getStatusConfig } from '../../utils/jobStatus';
import { fmtDate } from '../../utils/formatDate';

function Dashboard() {
  const dispatch = useDispatch();
  const { list: jobs, stats } = useSelector(s => s.jobs);
  const { user } = useSelector(s => s.auth);

  useEffect(() => {
    dispatch(fetchJobs());
    dispatch(fetchStats());
    dispatch(fetchNotifs());
    dispatch(fetchUnread());
  }, [dispatch]);

  const overdueJobs   = jobs.filter(j => j.status === 'OVERDUE');
  const atRiskJobs    = jobs.filter(j => j.status === 'AT_RISK');
  const pendingAccept = jobs.filter(j => j.status === 'PENDING');

  return (
    <div className="p-6">
      {/* AI Insight */}
      <div className="bg-brand-light border border-brand/20 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-brand text-white text-[9px] font-bold px-2 py-0.5 rounded tracking-wider">AI</span>
          <span className="font-semibold text-brand text-sm">Pulse Insight — Today</span>
        </div>
        <p className="text-sm text-gray-600 leading-relaxed">
          {overdueJobs.length > 0 ? <><strong>{overdueJobs.length} job{overdueJobs.length > 1 ? 's' : ''} overdue</strong> — {overdueJobs.map(j => j.title).join(', ')} need{overdueJobs.length === 1 ? 's' : ''} immediate action. </> : 'All overdue jobs cleared. '}
          {atRiskJobs.length > 0 ? <>{atRiskJobs.length} job{atRiskJobs.length > 1 ? 's' : ''} approaching deadline. </> : ''}
          {pendingAccept.length > 0 ? <>{pendingAccept.length} job{pendingAccept.length > 1 ? 's' : ''} awaiting acceptance. </> : ''}
          <span className="text-green-600">{stats ? `${Math.round((stats.active / Math.max(stats.total, 1)) * 100)}% of jobs on track.` : ''}</span>
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-6 gap-3 mb-6">
        <StatCard label="Total Jobs"  value={stats?.total    || 0} sub="Active"         dotColor="#6B7280" />
        <StatCard label="On Track"    value={stats?.active   || 0} sub="Within deadline" dotColor="#16A34A" />
        <StatCard label="At Risk"     value={stats?.at_risk  || 0} sub="Nearing deadline"dotColor="#CA8A04" />
        <StatCard label="Overdue"     value={stats?.overdue  || 0} sub="Needs action"    dotColor="#DC2626" />
        <StatCard label="Pending"     value={stats?.pending  || 0} sub="Awaiting accept" dotColor="#2563EB" />
        <StatCard label="In Review"   value={stats?.in_review|| 0} sub="QA / approval"   dotColor="#7C3AED" />
      </div>

      {/* Jobs table */}
      <div className="card">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
          <h2 className="font-semibold text-sm">Active Jobs</h2>
          <Button variant="ghost" size="sm" onClick={() => window.location.href = '/jobs'}>View all</Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-gray-50/70">
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Job</th>
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Client</th>
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Assignee</th>
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Status</th>
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Progress</th>
              <th className="text-left px-4 py-2.5 text-xs text-gray-400 font-medium">Deadline</th>
            </tr></thead>
            <tbody>
              {jobs.slice(0, 8).map(job => {
                const cfg = getStatusConfig(job.status);
                const days = getDaysLeft(job.due_date);
                return (
                  <tr key={job.id} onClick={() => dispatch(openPanel(job))} className="border-t border-gray-50 hover:bg-gray-50/70 cursor-pointer">
                    <td className="px-4 py-3">
                      <div className="font-medium text-sm text-gray-900">{job.title}</div>
                      <div className="text-xs text-gray-400">{job.type?.replace(/_/g,' ')}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">{job.client_name}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold text-white shrink-0" style={{ background: job.assignee_color || '#4F46E5' }}>{job.assignee_initials}</div>
                        <span className="text-xs">{job.assignee_name?.split(' ')[0]}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3"><StatusPill status={job.status} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <RingProgress percent={job.progress} color={cfg.color} size={32} strokeWidth={3} />
                        <span className="text-xs font-mono text-gray-500">{job.progress}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-xs font-mono font-semibold" style={{ color: days < 0 ? '#DC2626' : days <= 2 ? '#CA8A04' : '#374151' }}>
                        {days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? 'Due today' : `${days}d left`}
                      </div>
                      <div className="text-[10px] text-gray-400">Due {fmtDate(job.due_date, { day:'numeric', month:'short' })}</div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!jobs.length && <div className="text-center py-12 text-gray-400 text-sm">No jobs yet — create one to get started</div>}
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  return <AppShell><Topbar title="Dashboard" /></AppShell>;
}
