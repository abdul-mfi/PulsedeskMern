import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import API from '../../lib/api';

export const fetchJobs  = createAsyncThunk('jobs/fetchAll',   async (params = {}) => { const { data } = await API.get('/jobs', { params }); return data.data; });
export const fetchStats = createAsyncThunk('jobs/fetchStats', async () => { const { data } = await API.get('/jobs/stats'); return data.data; });
export const fetchJob   = createAsyncThunk('jobs/fetchOne',   async (id) => { const { data } = await API.get(`/jobs/${id}`); return data.data; });
export const createJob  = createAsyncThunk('jobs/create',     async (payload) => { const { data } = await API.post('/jobs', payload); return data.data; });
export const updateJob  = createAsyncThunk('jobs/update',     async ({ id, ...payload }) => { const { data } = await API.patch(`/jobs/${id}`, payload); return data.data; });
export const acceptJob  = createAsyncThunk('jobs/accept',     async (id) => { const { data } = await API.post(`/jobs/${id}/accept`); return data.data; });
export const rejectJob  = createAsyncThunk('jobs/reject',     async ({ id, reason }) => { const { data } = await API.post(`/jobs/${id}/reject`, { reason }); return data.data; });
export const completeJob= createAsyncThunk('jobs/complete',   async (id) => { const { data } = await API.post(`/jobs/${id}/complete`); return data.data; });
export const deleteJob  = createAsyncThunk('jobs/delete',     async (id) => { await API.delete(`/jobs/${id}`); return id; });

const jobsSlice = createSlice({
  name: 'jobs',
  initialState: { list: [], selected: null, stats: null, loading: false, error: null, filter: 'all' },
  reducers: {
    setFilter:   (s, { payload }) => { s.filter = payload; },
    setSelected: (s, { payload }) => { s.selected = payload; },
    upsertJob:   (s, { payload }) => { const idx = s.list.findIndex(j => j.id === payload.id); if (idx >= 0) s.list[idx] = payload; else s.list.unshift(payload); },
    removeJob:   (s, { payload }) => { s.list = s.list.filter(j => j.id !== payload); },
    updateStatus:(s, { payload: { jobId, status } }) => { const j = s.list.find(x=>x.id===jobId); if(j) j.status=status; if(s.selected?.id===jobId) s.selected.status=status; },
  },
  extraReducers: (b) => {
    b.addCase(fetchJobs.pending,   (s) => { s.loading = true; })
     .addCase(fetchJobs.fulfilled, (s, { payload }) => { s.loading = false; s.list = payload; })
     .addCase(fetchJobs.rejected,  (s, { payload }) => { s.loading = false; })
     .addCase(fetchStats.fulfilled,(s, { payload }) => { s.stats = payload; })
     .addCase(fetchJob.fulfilled,  (s, { payload }) => { s.selected = payload; })
     .addCase(createJob.fulfilled, (s, { payload }) => { s.list.unshift(payload); })
     .addCase(updateJob.fulfilled, (s, { payload }) => { const i = s.list.findIndex(j=>j.id===payload.id); if(i>=0) s.list[i]=payload; if(s.selected?.id===payload.id) s.selected=payload; })
     .addCase(acceptJob.fulfilled, (s, { payload }) => { const i = s.list.findIndex(j=>j.id===payload.id); if(i>=0) s.list[i]=payload; if(s.selected?.id===payload.id) s.selected=payload; })
     .addCase(completeJob.fulfilled,(s,{payload})=>{ const i=s.list.findIndex(j=>j.id===payload.id); if(i>=0) s.list[i]=payload; })
     .addCase(deleteJob.fulfilled, (s, { payload }) => { s.list = s.list.filter(j=>j.id!==payload); });
  },
});

export const { setFilter, setSelected, upsertJob, removeJob, updateStatus } = jobsSlice.actions;
export default jobsSlice.reducer;
